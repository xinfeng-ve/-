import org.bouncycastle.jce.provider.BouncyCastleProvider;
import javax.crypto.Cipher;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.*;
import java.util.Base64;
import javax.crypto.Cipher;

public class ECCWithoutCertificateExample {
    public static void main(String[] args) throws Exception {
        // 添加Bouncy Castle作为安全提供者
        Security.addProvider(new BouncyCastleProvider());

        // 生成椭圆曲线密钥对
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("EC", "BC");
        keyPairGenerator.initialize(521); // 设置密钥长度为256位
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        // 将公钥和私钥转换为Base64编码的字符串
        String publicKeyStr = Base64.getEncoder().encodeToString(publicKey.getEncoded());
        String privateKeyStr = Base64.getEncoder().encodeToString(privateKey.getEncoded());

        // 输出公钥和私钥字符串（在实际应用中，这些字符串需要安全地存储和传输）
        System.out.println("Public key (Base64): " + publicKeyStr);
        System.out.println("Private key (Base64): " + privateKeyStr);

        // 使用Base64编码的字符串恢复公钥和私钥
        KeyFactory keyFactory = KeyFactory.getInstance("EC", "BC");
        X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyStr));
        PublicKey recoveredPublicKey = keyFactory.generatePublic(publicKeySpec);
        PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyStr));
        PrivateKey recoveredPrivateKey = keyFactory.generatePrivate(privateKeySpec);

        // 待加密的数据
        byte[] originalData = "Hello, IoT!".getBytes();

        // 用于记录总时长

        long encryptionTimeTotal = 0;
        long decryptionTimeTotal = 0;
        int numIterations = 100;

        // 循环100次进行加密和解密操作
        for (int i = 0; i < 100; i++) {
            long encryptionStart = System.nanoTime();

            // 加密
        Cipher encryptCipher = Cipher.getInstance("ECIES", "BC");
        encryptCipher.init(Cipher.ENCRYPT_MODE, recoveredPublicKey);
        byte[] encryptedData = encryptCipher.doFinal(originalData);
        long encryptionEnd = System.nanoTime();
        encryptionTimeTotal += (encryptionEnd - encryptionStart);

        // 解密
            long decryptionStart = System.nanoTime();
        Cipher decryptCipher = Cipher.getInstance("ECIES", "BC");
        decryptCipher.init(Cipher.DECRYPT_MODE, recoveredPrivateKey);
        byte[] decryptedData = decryptCipher.doFinal(encryptedData);
            long decryptionEnd = System.nanoTime();
            decryptionTimeTotal += (decryptionEnd - decryptionStart);



        }

        // 计算平均时间
        long averageEncryptionTime = encryptionTimeTotal / numIterations;
        long averageDecryptionTime = decryptionTimeTotal / numIterations;




        // 输出解密后的数据
        System.out.println("Decrypted data: " + new String(originalData));

        System.out.println("Average encryption time over " + numIterations + " iterations: " + averageEncryptionTime + " nanoseconds");
        System.out.println("Average decryption time over " + numIterations + " iterations: " + averageDecryptionTime + " nanoseconds");
    }
}



//        long totalEncryptionTime = 0;
//        long totalDecryptionTime = 0;
//
//        for (int i = 0; i < 100; i++) {
//            long startTime = System.nanoTime();
//            byte[] ciphertext = encryptor.encrypt(plaintext);
//            long endTime = System.nanoTime();
//            totalEncryptionTime += (endTime - startTime);
//
//            startTime = System.nanoTime();
//            byte[] decryptedText = encryptor.decrypt(ciphertext);
//            endTime = System.nanoTime();
//            totalDecryptionTime += (endTime - startTime);
//        }
//
//        double averageEncryptionTime = totalEncryptionTime / 100.0 / 1_000_000; // 转换为毫秒
//        double averageDecryptionTime = totalDecryptionTime / 100.0 / 1_000_000; // 转换为毫秒
//
//        System.out.println("Average encryption time: " + averageEncryptionTime + " ms");
//        System.out.println("Average decryption time: " + averageDecryptionTime + " ms");
//    }
//}
//public class ECCWithoutCertificateExample {
//    public static void main(String[] args) throws Exception {
//        Security.addProvider(new BouncyCastleProvider());
//
//        // 由于没有证书的相关校验，这里的公私钥需要事先安全地传送并存储
//        String publicKeyStr = ""; // 从安全存储中获取公钥的字符串表示
//        String privateKeyStr = ""; // 从安全存储中获取私钥的字符串表示
//
//        KeyFactory keyFactory = KeyFactory.getInstance("EC", "BC");//算法，提供者
//
//        // 获取公钥
//        X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyStr));
//        PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
//
//        // 获取私钥
//        PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyStr));
//        PrivateKey privateKey = keyFactory.generatePrivate(privateKeySpec);
//
//        // 待加密的数据
//        byte[] originalData = "Hello, IoT!".getBytes();
//
//        // 加密
//        Cipher encryptCipher = Cipher.getInstance("ECIES", "BC");
//        encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);
//        byte[] encryptedData = encryptCipher.doFinal(originalData);
//
//        // 解密
//        Cipher decryptCipher = Cipher.getInstance("ECIES", "BC");
//        decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
//        byte[] decryptedData = decryptCipher.doFinal(encryptedData);
//
//        System.out.println("Decrypted data: " + new String(decryptedData));
//    }
//}
