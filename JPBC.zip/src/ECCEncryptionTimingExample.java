import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import javax.crypto.Cipher;

public class ECCEncryptionTimingExample {
    public static void main(String[] args) throws Exception {
        Security.addProvider(new BouncyCastleProvider());

        // 创建密钥对
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("EC", "BC");
        keyPairGenerator.initialize(256);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        // 准备数据
        byte[] originalData = "Hello, IoT!".getBytes();

        // 循环执行加密和解密，各100次
        long encryptionTimeTotal = 0;
        long decryptionTimeTotal = 0;
        int numIterations = 100;

        for (int i = 0; i < numIterations; i++) {
            // 加密
            long encryptionStart = System.nanoTime();
            Cipher encryptCipher = Cipher.getInstance("ECIES", "BC");
            encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] encryptedData = encryptCipher.doFinal(originalData);
            long encryptionEnd = System.nanoTime();
            encryptionTimeTotal += (encryptionEnd - encryptionStart);

            // 解密
            long decryptionStart = System.nanoTime();
            Cipher decryptCipher = Cipher.getInstance("ECIES", "BC");
            decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
            byte[] decryptedData = decryptCipher.doFinal(encryptedData);
            long decryptionEnd = System.nanoTime();
            decryptionTimeTotal += (decryptionEnd - decryptionStart);
        }

        // 计算平均时间
        long averageEncryptionTime = encryptionTimeTotal / numIterations;
        long averageDecryptionTime = decryptionTimeTotal / numIterations;

        System.out.println("Average encryption time over " + numIterations + " iterations: " + averageEncryptionTime + " nanoseconds");
        System.out.println("Average decryption time over " + numIterations + " iterations: " + averageDecryptionTime + " nanoseconds");
    }
}
