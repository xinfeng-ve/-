
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import javax.crypto.Cipher;

public class EncryptionTimingExample {
    public static void main(String[] args) throws Exception {
        Security.addProvider(new BouncyCastleProvider());

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
        keyPairGenerator.initialize(15360);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        byte[] originalData = "Hello, IoT!".getBytes();

        // 循环运行加密和解密过程，各100次
        long encryptionTimeTotal = 0;
        long decryptionTimeTotal = 0;
        int numIterations = 100;

        for (int i = 0; i < numIterations; i++) {
            // 加密
            long encryptionStart = System.nanoTime();
            Cipher encryptCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
            encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] encryptedData = encryptCipher.doFinal(originalData);
            long encryptionEnd = System.nanoTime();
            encryptionTimeTotal += (encryptionEnd - encryptionStart);

            // 解密
            long decryptionStart = System.nanoTime();
            Cipher decryptCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
            decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
            byte[] decryptedData = decryptCipher.doFinal(encryptedData);
            long decryptionEnd = System.nanoTime();
            decryptionTimeTotal += (decryptionEnd - decryptionStart);
        }

        // 计算平均时间
        long averageEncryptionTime = encryptionTimeTotal / numIterations;
        long averageDecryptionTime = decryptionTimeTotal / numIterations;

        System.out.println("Average encryption time over " + numIterations + " iterations: " + averageEncryptionTime + " nanoseconds");
        System.out.println("Average decryption time over " + numIterations + " iterations: " + averageDecryptionTime + " nanoseconds");
    }
}
